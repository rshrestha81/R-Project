#Study: GID Clinical - Reshma Shrestha - 2017
#
#Time-Series Prediction Model of Conversion from predictive data sets
#in Adwords to match actual results for time period January 2013 - March 2015
#using ARIMA Model
#
#

install.packages("forecast")
library(forecast)
library(xlsx)

#exploratory data analysis
#GInq <- read.xlsx("GID-Clinical Conv.xlsx", sheetIndex = 1)
#GInq
#head(GInq)
#class(GInq)
#summary(GInq$Conversions)

#exploratory data analysis for 6 months data
GInqsm <- read.xlsx("GID-Clinical Conv6m.xlsx", sheetIndex = 1)
GInqsm
head(GInqsm)
class(GInqsm)
summary(GInqsm$Conversions)

#detailed metrics
plot(GInq)
plot(GInq$Conversions)
abline(lm(GInq$Conversions~GInq$Month), col="red")
lines(lowess(GInq$Month, GInq$Conversions), col="blue")

#detailed metrics GIDsm
plot(GInqsm)
plot(GInqsm$Conversions)
abline(lm(GInqsm$Conversions~GInqsm$Month), col="red")
lines(lowess(GInqsm$Month, GInqsm$CPI), col="blue")

#creating time series
GInqts <- ts(GInq$Conversions, frequency = 12)
GInqts
class(GInqts)
start(GInqts)
end(GInqts)
summary(GInqts)

#creating time series for GIDsm
GInqsmts <- ts(GInqsm$Conversions, frequency = 12)
GInqsmts
class(GInqsmts)
start(GInqsmts)
end(GInqsmts)
summary(GInqsmts)

#Scatterplot smoothing to see trends
plot(GInqts, ylab="Conversions")
abline(reg=lm(GInqts~time(GInqts)), col="red")
lines(lowess(GInqts), col="blue")

#Scatterplot smoothing to see trends for GID 12 months data
plot(GInqsmts, ylab="Conversions")
abline(reg=lm(GInqsmts~time(GInqsmts)), col="red")
lines(lowess(GInqsmts), col="blue")

#re-create time-series data
GInqts <- ts(GInq$Conversions, start = c(2013, 1), end = c(2015, 3), frequency = 12)
GInqts
class(GInqts)
start(GInqts)
end(GInqts)
frequency(GInqts)
summary(GInqts)
plot(GInqts, ylab="Conversions", xlab="Months")
abline(reg=lm(GInqts~time(GInqts)), col="red")
lines(lowess(GInqts), col="blue")

#re-create time-series data for GInq 6m
GInqsmts <- ts(GInqsm$Conversions, start = c(2013, 1), end = c(2014, 7), frequency = 12)
GInqsmts
class(GInqsmts)
start(GInqsmts)
end(GInqsmts)
frequency(GInqsmts)
summary(GInqsmts)
plot(GInqsmts, ylab="Conversion", xlab="Months")
abline(reg=lm(GInqsmts~time(GInqsmts)), col="red")
lines(lowess(GInqsmts), col="blue")

#additional plots
monthplot(GInqts)
seasonplot(GInqts)

#additional plots - Gsmts
monthplot(GInqsmts)
seasonplot(GInqsmts)

#print the cycle across years
cycle(GInqts)
#aggregate the cycles to display yearly trend
plot(aggregate(GInqts, FUN=mean))
#Plotted against months to display seasonal effect
boxplot(GInqts~cycle(GInqts))

#print the cycle across years - GInqsmts
cycle(GInqsmts)
#aggregate the cycles to display yearly trend
plot(aggregate(GInqsmts, FUN=mean))
#Plotted against months to display seasonal effect
boxplot(GInqsmts~cycle(GInqsmts))

#Augmented Dickey-Fuller Test - series is stationary
adf.test(diff(log(GInqts)), alternative = "stationary", k=0)

acf(log(GInqts))
acf(diff(log(GInqts)))
pacf(diff(log(GInqts)))

#Augmented Dickey-Fuller Test - series is stationary - Gsmts
adf.test(diff(log(GInqsmts)), alternative = "stationary", k=0)

acf(log(GInqsmts))
acf(diff(log(GInqsmts)))
pacf(diff(log(GInqsmts)))

#compute p,d,q in ARIMA
trendsarima <- auto.arima(GInqts)
trendsarima
trendsarima <- auto.arima(GInqsmts)
trendsarima

#ARIMA MOdel for time-series prediction (Actual Data - 2 years 3 months)
m3 <- arima(log(GInqts), c(1,0,0), seasonal = list(order=c(1,0,0), period=12))
predConv <- predict(m3, n.ahead = 3*12) #predict for future years
ts.plot(GInqts, 2.718^predConv$pred, log = "y", lty = c(1,3))

#ARIMA model for time-series prediction (Actual Data - 1.6 years)
m4 <- arima(log(GInqsmts), c(1,0,0), seasonal = list(order=c(1,0,0), period=12), method = "ML")
predm4Conv <- predict(m4, n.ahead = 4*12) #predict for future years
ts.plot(GInqsmts, 2.718^predm4Conv$pred, log = "y", lty = c(1,3))

save(GInq, GInqts, m3, trendsarima, file="MDCConv1.RData")
save(GInqsm, GInqsmts, m4, trendsarima, file="MDCConv2.RData")

#install.packages("Rserve")
#library(Rserve)
#Rserve()
