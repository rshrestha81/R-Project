#Study: GID Clinical - Reshma Shrestha - 2017
#
#Time-Series Prediction Model of Cost Per Inquiry from predictive data sets
#in Adwords to match actual results for time period January 2013 - March 2015
#using ARIMA Model
#
#Source: https://www.analyticsvidhya.com/blog/2015/12/complete-tutorial-time-series-modeling/
#

#install & activate packages
install.packages("forecast")
library(forecast)
library(xlsx)

#exploratory data analysis
#GID <- read.xlsx("GID-Clinical CPI.xlsx", sheetIndex = 1)
#GID
#head(GID)
#class(GID)
#summary(GID$CPI)

#exploratory data analysis for 6 months data
GIDsm <- read.xlsx("GID-Clinical CPI6m.xlsx", sheetIndex = 1)
GIDsm
head(GIDsm)
class(GIDsm)
summary(GIDsm$CPI)

#detailed metrics
#plot(GID)
#abline(lm(GID$CPI~GID$Month), col="red")
#lines(lowess(GID$Month, GID$CPI), col="blue")

#detailed metrics GIDsm
plot(GIDsm)
abline(lm(GIDsm$CPI~GIDsm$Month), col="red")
lines(lowess(GIDsm$Month, GIDsm$CPI), col="blue")

#creating time series object for CPI to view monthly data
#Gts <- ts(GID$CPI, frequency = 12)
#Gts
#class(Gts)
#start(Gts)
#end(Gts)
#summary(Gts)

#creating time series object for CPI to view 1.5 year data on monthly basis
Gsmts <- ts(GIDsm$CPI, frequency = 12)
Gsmts
class(Gsmts)
start(Gsmts)
end(Gsmts)
summary(Gsmts)

#Scatterplot smoothing to see trends
#plot(Gts, ylab="CPI")
#abline(reg=lm(Gts~time(Gts)), col="red")
#lines(lowess(Gts), col="blue")

#Scatterplot smoothing to see trends for GID 15 months of data
plot(Gsmts, ylab="CPI")
abline(reg=lm(Gsmts~time(Gsmts)), col="red")
lines(lowess(Gsmts), col="blue")

#re-create time-series object
#Gts <- ts(GID$CPI, start = c(2013, 1), end = c(2015, 3), frequency = 12)
#Gts
#class(Gts)
#start(Gts)
#end(Gts)
#frequency(Gts)
#summary(Gts)
#plot(Gts, ylab="CPI", xlab="Months")
#abline(reg=lm(Gts~time(Gts)), col="red")
#lines(lowess(Gts), col="blue")

#re-create time-series data for another dataset that had 5 months less of original dataset
Gsmts <- ts(GIDsm$CPI, start = c(2013, 1), end = c(2014, 6), frequency = 12)
Gsmts
class(Gsmts)
start(Gsmts)
end(Gsmts)
frequency(Gsmts)
summary(Gsmts)
plot(Gsmts, ylab="CPI", xlab="Months")
abline(reg=lm(Gsmts~time(Gsmts)), col="red")
lines(lowess(Gsmts), col="blue")

#additional plots to analyze seasonality
#monthplot(Gts)
#seasonplot(Gts)

#additional plots to analyze seasonality for 2nd dataset
monthplot(Gsmts)
seasonplot(Gsmts)

#print the cycle across years
#cycle(Gts)
#aggregate the cycles to display yearly trend
#plot(aggregate(Gts, FUN=mean))
#Plotted against months to display seasonal effect
#boxplot(Gts~cycle(Gts))

#print the cycle across years - for 2nd dataset
cycle(Gsmts)
#aggregate the cycles to display yearly trend
plot(aggregate(Gsmts, FUN=mean))
#Plotted against months to display seasonal effect
boxplot(Gsmts~cycle(Gsmts))

#Augmented Dickey-Fuller Test - series is stationary
#adf.test(diff(log(Gts)), alternative = "stationary", k=0)
#acf(log(Gts))
#acf(diff(log(Gts)))
#pacf(diff(log(Gts)))

#Augmented Dickey-Fuller Test - series is stationary - Gsmts
library(tseries)
adf.test(diff(log(Gsmts)), alternative = "stationary", k=0)

acf(log(Gsmts))
acf(diff(log(Gsmts)))
pacf(diff(log(Gsmts)))

#compute p,d,q for ARIMA model
#trendsarima <- auto.arima(Gts)
#trendsarima
trendsarima <- auto.arima(Gsmts)
trendsarima

#ARIMA Model for time-series prediction (Actual Dataset from Adwords - 2 years 3 months)
#m <- arima(log(Gts), c(1,1,0), seasonal = list(order=c(1,1,0), period=12))
#predCPI <- predict(m, n.ahead = 2*12) 
#ts.plot(Gts, 2.718^predCPI$pred, log = "y", lty = c(1,3))

#ARIMA model for time-series prediction (Actual Data from Adwords - 1.5 years)
m1 <- arima(log(Gsmts), c(0,1,0), seasonal = list(order=c(0,1,0), period=12))
predm1CPI <- predict(m1, n.ahead = 1.5*12) #predict for future 1.5 years to match the results of original dataset Gts
ts.plot(Gsmts, 2.718^predm1CPI$pred, log = "y", lty = c(1,3))

#save the file as .RData for Tableau Visualization
#save(GID, Gts, m, trendsarima, file="MDC1.RData")
save(GIDsm, Gsmts, m1, trendsarima, file="MDC2.RData")
